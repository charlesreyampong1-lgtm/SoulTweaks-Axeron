#!/system/bin/sh
# Underrated v3.1 — uninstall.sh

pkill -f "loop.sh" > /dev/null 2>&1

# Remove files — use $MODDIR if available, fallback path otherwise
MOD="${MODDIR:-/sdcard/Android/data/frb.axeron.manager/files}"
rm -f "$MOD/loop.sh"
rm -f "$MOD/optimizer.log"
rm -f "$MOD/hw_hz"
rm -f "$MOD/hw_vulkan"

# Reset display density
wm density reset

# Remove game performance modes (read from games.list if it exists)
if [ -f "$MOD/games.list" ]; then
    while IFS= read -r pkg; do
        [ -z "$pkg" ] && continue
        cmd game mode standard "$pkg" 2>/dev/null
    done < "$MOD/games.list"
fi

# Clear settings overrides
settings delete global peak_refresh_rate
settings delete global user_refresh_rate
settings delete system  min_refresh_rate
settings delete global power_id
settings delete global adaptive_battery_management_enabled

# FIX: clear debug props with setprop
setprop debug.hwui.renderer ""
setprop debug.renderengine.backend ""

# Restore animations
settings put system window_animation_scale    1.0
settings put system transition_animation_scale 1.0
settings put system animator_duration_scale   1.0

cmd battery reset > /dev/null 2>&1

echo "[Underrated] Uninstall complete — all values restored to stock"
