#!/system/bin/sh
# Underrated v3.1 — action.sh (Fixed Unrooted Edition)
# Axeron sets $MODDIR automatically — fallback to backup if blank

# Siguraduhing may fallback path kung tinakbo sa labas ng Axeron App
[ -z "$MODDIR" ] && MODDIR="/data/user_de/0/com.android.shell/axeron/plugins/underrated"
[ ! -d "$MODDIR" ] && MODDIR="/sdcard/Axeron_Plugins_Backup/underrated"

# Ituro sa loob ng daemon folder kung nasaan ang ginawa mong loop.sh
LOOP_FILE="$MODDIR/daemon/loop.sh"
LOG_FILE="$MODDIR/optimizer.log"
GAMES_LIST="$MODDIR/games.list"

# Kill any existing loop
pkill -f "loop.sh" > /dev/null 2>&1
cmd battery reset > /dev/null 2>&1

# Detect max Hz and Vulkan once — pass into loop via file
MAX_HZ=$(dumpsys display 2>/dev/null | grep -oE "60\.0|90\.0|120\.0|144\.0|165\.0" | sort -rn | head -1 | cut -d'.' -f1)
[ -z "$MAX_HZ" ] && MAX_HZ=60

if [ -f "/vendor/lib/libvulkan.so" ] || [ -f "/vendor/lib64/libvulkan.so" ]; then
    VULKAN_SUPPORT="true"
else
    VULKAN_SUPPORT="false"
fi

# Save hw caps so loop can read them without re-detecting every 5s
echo "$MAX_HZ"        > "$MODDIR/hw_hz"
echo "$VULKAN_SUPPORT" > "$MODDIR/hw_vulkan"

echo "Underrated v3.1: Engine started (${MAX_HZ}Hz, Vulkan=${VULKAN_SUPPORT})"

# Binago: Direkta nang tinatawag ang ginawa mong loop.sh sa daemon folder nang walang cat restriction
chmod +x "$LOOP_FILE" 2>/dev/null
nohup sh "$LOOP_FILE" > /dev/null 2>&1 &