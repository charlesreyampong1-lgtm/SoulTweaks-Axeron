#!/system/bin/sh
# Underrated v3.1 — background loop (Fixed Path Edition)

MODDIR="/data/user_de/0/com.android.shell/axeron/plugins/underrated"
[ ! -d "$MODDIR" ] && MODDIR="/sdcard/Axeron_Plugins_Backup/underrated"

LAST_STATE=""
LAST_GAME=""
LOG_F="$MODDIR/optimizer.log"
GAMES_F="$MODDIR/games.list"

MAX_HZ=$(cat "$MODDIR/hw_hz" 2>/dev/null || echo "60")
VULKAN=$(cat "$MODDIR/hw_vulkan" 2>/dev/null || echo "false")

apply_vulkan() {
    if [ "$VULKAN" = "true" ]; then
        setprop debug.hwui.renderer skiavk
        setprop debug.renderengine.backend vulkan
    fi
}

reset_vulkan() {
    setprop debug.hwui.renderer ""
    setprop debug.renderengine.backend ""
}

detect_game() {
    CURRENT_GAME=""
    [ ! -f "$GAMES_F" ] && return
    while IFS= read -r pkg; do
        [ -z "$pkg" ] && continue
        if pgrep -f "$pkg" > /dev/null 2>&1; then
            CURRENT_GAME="$pkg"
            return
        fi
    done < "$GAMES_F"
}

is_plugged() {
    dumpsys battery 2>/dev/null | grep -E "AC powered:|USB powered:|Wireless powered:" | grep -q "true"
}

while true; do
    detect_game

    if is_plugged; then
        REAL_PLUGGED=1
    else
        REAL_PLUGGED=0
        cmd battery reset > /dev/null 2>&1
    fi

    if [ -n "$CURRENT_GAME" ]; then
        if [ "$LAST_STATE" != "performance" ] || [ "$LAST_GAME" != "$CURRENT_GAME" ]; then
            [ "$REAL_PLUGGED" -eq 1 ] && cmd battery unplug > /dev/null 2>&1

            cmd power set-mode 0
            settings put global power_id 2
            settings put global adaptive_battery_management_enabled 0
            settings put global peak_refresh_rate "${MAX_HZ}.0"
            settings put global user_refresh_rate  "${MAX_HZ}.0"
            settings put system  min_refresh_rate  "${MAX_HZ}.0"
            apply_vulkan

            echo "[$(date +%H:%M:%S)] PERF — game: $CURRENT_GAME | plugged: $REAL_PLUGGED" > "$LOG_F"
            LAST_STATE="performance"
            LAST_GAME="$CURRENT_GAME"
        fi

    elif [ "$REAL_PLUGGED" -eq 1 ]; then
        if [ "$LAST_STATE" != "fast_charging" ]; then
            cmd battery reset > /dev/null 2>&1
            cmd power set-mode 2
            settings put global power_id 1
            settings put global adaptive_battery_management_enabled 1
            settings put global peak_refresh_rate "${MAX_HZ}.0"
            settings put global user_refresh_rate  "${MAX_HZ}.0"
            reset_vulkan

            echo "[$(date +%H:%M:%S)] IDLE — fast charging" > "$LOG_F"
            LAST_STATE="fast_charging"
            LAST_GAME=""
        fi

    else
        if [ "$LAST_STATE" != "balanced" ]; then
            cmd battery reset > /dev/null 2>&1
            cmd power set-mode 2
            settings put global power_id 1
            settings put global adaptive_battery_management_enabled 1
            settings put global peak_refresh_rate "${MAX_HZ}.0"
            settings put global user_refresh_rate  "${MAX_HZ}.0"
            reset_vulkan

            echo "[$(date +%H:%M:%S)] BALANCED — no game, unplugged" > "$LOG_F"
            LAST_STATE="balanced"
            LAST_GAME=""
        fi
    fi

    sleep 5
done