#!/system/bin/sh
# Persistent daemon - No-Temp-File Echo Mode

AXERON_MODDIR="/data/user_de/0/com.android.shell/axeron/plugins/SoulTweaks"

# Tiyakin kung saan may karapatang magsulat ang shell process mo
if [ -d "$AXERON_MODDIR" ]; then
    mkdir -p "$AXERON_MODDIR/logs"
    LOGFILE="$AXERON_MODDIR/logs/daemon.log"
    STATUSFILE="$AXERON_MODDIR/underrated_status.json"
else
    mkdir -p "/sdcard/Axeron_Plugins_Backup/SoulTweaks/logs"
    LOGFILE="/sdcard/Axeron_Plugins_Backup/SoulTweaks/logs/daemon.log"
    STATUSFILE="/sdcard/Axeron_Plugins_Backup/SoulTweaks/underrated_status.json"
fi

while true; do
  TIMESTAMP=$(date +"%Y-%m-%d %H:%M:%S")
  
  # Pagsulat ng run log
  echo "[$TIMESTAMP] Underrated daemon running - Monitoring system..." >> "$LOGFILE"
  
  # Inalis ang << EOF. Ginamit ang purong echo string para walang permission denied crash sa /data/local/
  echo '{"status": "active", "timestamp": "'"$TIMESTAMP"'", "cpu_governor": "schedutil", "message": "Daemon bridge live via Clean Echo"}' > "$STATUSFILE"

  sleep 15
done