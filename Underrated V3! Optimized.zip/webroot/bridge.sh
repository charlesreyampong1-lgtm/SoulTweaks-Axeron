#!/system/bin/sh
# Underrated v3.1 — bridge.sh (Underrated Target Fixed)

# Ituro sa tamang pangalan ng folder base sa screenshot mo
MODDIR="/sdcard/Axeron_Plugins_Backup/underrated"

BRIDGE_FLAG="$MODDIR/bridge_active"
LOG="$MODDIR/bridge.log"

echo "[$(date +%H:%M:%S)] >>> Bridge start requested" > "$LOG"

# Patayin ang mga nakabitin na lumang loops
pkill -f "loop.sh" > /dev/null 2>&1
pkill -f "action.sh" > /dev/null 2>&1

# I-on ang flag para mag-green dot ang WebUI
echo "1" > "$BRIDGE_FLAG"

# Patakbuhin si action.sh sa background nang hindi nagha-hang ang terminal
(sh "$MODDIR/action.sh" >> "$LOG" 2>&1 &)

echo "[$(date +%H:%M:%S)] >>> Bridge active — engine running" >> "$LOG"
exit 0