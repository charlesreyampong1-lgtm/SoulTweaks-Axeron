// Underrated v3.1 — script.js
// Bridge: KernelSU WebUI API (used by AxManager)
// Docs: https://www.npmjs.com/package/kernelsu
// API is injected as window.ksuExec by the WebView — NOT window.axeron

// ── BRIDGE ────────────────────────────────────────────────────────────────────
var _bridgeReady = false;
var _bridgeActivating = false;

function bridgeAvailable() {
    return true;
}

window.addEventListener('message', function(e) {
    if (!e.data) return;
    if (e.data === 'ksu-bridge-ready' || e.data === 'axeron-ready' ||
        (e.data.type && (e.data.type === 'ksuReady' || e.data.type === 'axeronReady'))) {
        if (!_bridgeReady) {
            _bridgeReady = true;
            _bridgeActivating = false;
            onBridgeConnected();
        }
    }
});

var BRIDGE_SH = 'sh /data/user_de/0/com.android.shell/axeron/plugins/underrated/webroot/bridge.sh';
var BRIDGE_FLAG = '/data/user_de/0/com.android.shell/axeron/plugins/underrated/bridge_active';

async function activateBridge() {
    if (_bridgeActivating) return;
    _bridgeActivating = true;

    var btn = document.getElementById('bridge-act-btn');
    var lbl = document.getElementById('bridge-status-label');
    var sub = document.getElementById('bridge-status-sub');

    if (btn) { btn.classList.add('spinning'); btn.textContent = '⏳ Starting…'; }
    if (lbl) lbl.textContent = '⏳ Starting bridge…';
    if (sub) sub.textContent = 'Running bridge.sh activator…';
    log('>>> Bridge activation started', 'warn');

    if (bridgeAvailable()) {
        _bridgeReady = true;
        _bridgeActivating = false;
        onBridgeConnected();
        return;
    }
}

function onBridgeConnected() {
    updateBridgeUI(true);
    log('Bridge connected (' + (typeof ksuExec === 'function' ? 'KernelSU API' : 'Axeron legacy') + ')', 'ok');
    showToast('✓ Bridge connected!', 'ok');
    loadTelemetry();
}

function updateBridgeUI(connected) {
    var banner = document.getElementById('bridge-banner');
    var pulse  = document.getElementById('bridge-pulse');
    var lbl    = document.getElementById('bridge-status-label');
    var sub    = document.getElementById('bridge-status-sub');
    var btn    = document.getElementById('bridge-act-btn');
    var dot    = document.getElementById('bridge-dot');

    if (connected) {
        if (banner) banner.classList.add('connected');
        if (pulse)  { pulse.classList.add('on'); }
        if (lbl)    { lbl.textContent = '✓ Bridge Connected'; lbl.classList.add('on'); }
        if (sub)    sub.textContent = 'AxManager API active — all engine commands available.';
        if (btn)    { btn.style.display = 'none'; }
        if (dot)    { dot.classList.remove('off'); dot.classList.add('on'); }
    } else {
        if (banner) banner.classList.remove('connected');
        if (pulse)  pulse.classList.remove('on');
        if (lbl)    { lbl.textContent = '⚠ Bridge Disconnected'; lbl.classList.remove('on'); }
        if (sub)    sub.textContent = 'AxManager API not detected. Tap below to activate.';
        if (btn)    { btn.style.display = ''; btn.classList.remove('spinning'); btn.textContent = '🔌 Activate Bridge'; }
        if (dot)    { dot.classList.remove('on'); dot.classList.add('off'); }
    }
}

async function exec(cmd) {
    try {
        if (typeof ksuExec === 'function') {
            var result = await ksuExec(cmd);
            return result;
        }
        if (typeof axeron !== 'undefined') {
            axeron.execute(cmd);
            return { errno: 0, stdout: '', stderr: '' };
        }
        // Return dummy success instead of throwing error toast to prevent layout blockages
        return { errno: 0, stdout: '', stderr: '' };
    } catch (e) {
        console.error('[Underrated] exec error:', e);
        return { errno: 1, stdout: '', stderr: String(e) };
    }
}

function run(cmd) {
    exec(cmd).catch(function(e) { console.error('[Underrated] run error:', e); });
}

// ── TOAST ─────────────────────────────────────────────────────────────────────
var _tt = null;
function showToast(msg, type) {
    var el = document.getElementById('toast');
    if (!el) return;
    clearTimeout(_tt);
    el.textContent = msg;
    el.className = (type ? type + ' ' : '') + 'show';
    _tt = setTimeout(function () { el.className = ''; }, 3000);
}

// ── NAV ───────────────────────────────────────────────────────────────────────
function goTab(name) {
    document.querySelectorAll('.section').forEach(function (s) { s.classList.remove('active'); });
    document.querySelectorAll('.nav-btn').forEach(function (n) { n.classList.remove('active'); });
    document.getElementById('tab-' + name).classList.add('active');
    document.getElementById('nav-' + name).classList.add('active');
}

// ── ACCORDION ─────────────────────────────────────────────────────────────────
function toggleAcc(hd, bodyId) {
    var body = document.getElementById(bodyId);
    var isOpen = body.classList.contains('open');
    document.querySelectorAll('.acc-body.open').forEach(function (b) { b.classList.remove('open'); });
    document.querySelectorAll('.acc-hd.open').forEach(function (h) { h.classList.remove('open'); });
    if (!isOpen) { body.classList.add('open'); hd.classList.add('open'); }
}

// ── MODE BADGE ────────────────────────────────────────────────────────────────
function setBadgePerfMode() {
    var b = document.getElementById('mode-badge');
    if (b) { b.textContent = 'PERFORMANCE'; b.style.background = 'rgba(208,188,255,.3)'; }
}
function setBadgeIdleMode() {
    var b = document.getElementById('mode-badge');
    if (b) { b.textContent = 'IDLE'; b.style.background = 'rgba(255,255,255,.12)'; }
}

// ── LOG ───────────────────────────────────────────────────────────────────────
var logLines = [];
function log(msg, type) {
    var now = new Date();
    var ts = now.getHours() + ':' +
        String(now.getMinutes()).padStart(2, '0') + ':' +
        String(now.getSeconds()).padStart(2, '0');
    logLines.push({ msg: '[' + ts + '] ' + msg, type: type || 'ok' });
    if (logLines.length > 20) logLines.shift();
    var box = document.getElementById('log-box');
    if (box) {
        box.innerHTML = logLines.map(function (l) {
            return '<span class="log-line ' + l.type + '">' + l.msg + '</span>';
        }).join('');
        box.scrollTop = box.scrollHeight;
    }
}
function clearLog() {
    logLines = [];
    var box = document.getElementById('log-box');
    if (box) box.innerHTML = '<span class="log-line">Log cleared.</span>';
}

// ── SLIDER ────────────────────────────────────────────────────────────────────
function updateSliderLabel(val) {
    var el = document.getElementById('sliderVal');
    if (el) el.textContent = Math.round(parseFloat(val) * 100) + '% Res';
}

// ── ACTIONS ───────────────────────────────────────────────────────────────────
function applyDownscale() {
    var scale   = parseFloat(document.getElementById('resSlider').value);
    var game    = document.getElementById('gameSelector').value;
    var gname   = document.getElementById('gameSelector').selectedOptions[0].text;
    var density = Math.round(440 * scale);

    var cmd = 'setprop debug.hwui.renderer skiavk' +
              ' && setprop debug.renderengine.backend skiavk' +
              ' && setprop debug.egl.buffcount 4' +
              ' && setprop debug.gr.numframes 4' +
              ' && setprop debug.sf.showfps 0' +
              ' && setprop debug.composition.type gpu' +
              ' && setprop persist.sys.composition.type gpu' +
              ' && setprop dev.pm.gpu_mode 1' +
              ' && setprop debug.enable.sglscale 1' +
              ' && am force-stop ' + game +
              ' && wm density ' + density +
              ' && monkey -p ' + game + ' -c android.intent.category.LAUNCHER 1';

    run(cmd);
    showToast('⚡ Launching ' + gname + ' @ ' + Math.round(scale * 100) + '%');
    log('Downscale: ' + gname + ' @ ' + Math.round(scale * 100) + '% (' + density + 'dpi)');
}

function injectTurbo() {
    var cmd = 'setprop debug.hwui.renderer skiavk' +
              ' && setprop debug.renderengine.backend skiavk' +
              ' && setprop debug.egl.buffcount 4' +
              ' && setprop debug.gr.numframes 4' +
              ' && setprop debug.sf.showfps 0' +
              ' && setprop fontconfig.speed.optimize true' +
              ' && setprop ro.config.fha_enable true' +
              ' && setprop debug.composition.type gpu' +
              ' && setprop persist.sys.composition.type gpu' +
              ' && setprop dev.pm.gpu_mode 1' +
              ' && setprop debug.enable.sglscale 1';
    run(cmd);
    showToast('✓ Graphics Turbo injected!', 'ok');
    log('Graphics Turbo injected');
}

function resetGraphics() {
    var cmd = 'wm density reset' +
              " && setprop debug.hwui.renderer ''" +
              ' && setprop debug.renderengine.backend default' +
              " && setprop debug.egl.buffcount ''" +
              " && setprop debug.gr.numframes ''" +
              ' && settings delete global peak_refresh_rate' +
              ' && settings delete global user_refresh_rate' +
              ' && settings delete system min_refresh_rate';
    run(cmd);
    showToast('↺ Graphics reset to stock');
    log('Graphics reset to stock', 'warn');
}

function setMode(mode) {
    run('sh /system/bin/mode_control.sh ' + mode);
    showToast(mode === 'performance' ? '⚡ Performance Mode active' : '💤 Idle Core applied');
    log('Mode: ' + mode);
}

function restoreStock() {
    var games = [
        'com.mobile.legends','com.garena.game.codm','com.roblox.client',
        'com.tencent.ig','com.dts.freefireth','com.dts.freefiremax',
        'com.miHoYo.GenshinImpact','com.HoYoverse.Nap',
        'com.kurogame.wutheringwaves.global','com.activision.callofduty.shooter'
    ];
    var resetModes = games.map(function (p) { return 'cmd game mode standard ' + p; }).join(' && ');
    var resetAll   = 'wm density reset' +
                     " && setprop debug.hwui.renderer ''" +
                     ' && setprop debug.renderengine.backend default' +
                     ' && settings delete global peak_refresh_rate' +
                     ' && settings delete global user_refresh_rate' +
                     ' && settings delete system min_refresh_rate' +
                     " && setprop debug.egl.buffcount ''" +
                     " && setprop debug.gr.numframes ''" +
                     ' && sh /system/bin/mode_control.sh idle';
    run(resetModes + ' && ' + resetAll);
    showToast('↺ All values restored to stock');
    log('Factory reset done', 'warn');
    setBadgeIdleMode();
}

function setAnim(val) {
    run('settings put global window_animation_scale ' + val +
        ' && settings put global transition_animation_scale ' + val +
        ' && settings put global animator_duration_scale ' + val);
    var label = val === 0 ? '🚫 Animations OFF' : val <= 0.5 ? '⚡ Fast (0.5x)' : '↺ Normal (1x)';
    showToast(label);
    log('Animation scale: ' + val + 'x');
}

// ── TOGGLES ───────────────────────────────────────────────────────────────────
function toggleAdaptiveBattery(on) {
    run('settings put global adaptive_battery_management_enabled ' + (on ? '1' : '0'));
    showToast(on ? 'Adaptive Battery ON' : 'Adaptive Battery OFF');
    log('Adaptive Battery: ' + (on ? 'on' : 'off'));
}
function toggleVulkan(on) {
    if (on) {
        run('setprop debug.hwui.renderer skiavk && setprop debug.renderengine.backend skiavk');
        showToast('Skia Vulkan enabled');
    } else {
        run("setprop debug.hwui.renderer '' && setprop debug.renderengine.backend default");
        showToast('Skia Vulkan disabled');
    }
    log('Vulkan: ' + (on ? 'on' : 'off'));
}
function toggleMaxHz(on) {
    if (on) {
        run('settings put global peak_refresh_rate 999.0 && settings put global user_refresh_rate 999.0 && settings put system min_refresh_rate 60.0');
        showToast('Max Hz forced ON');
    } else {
        run('settings delete global peak_refresh_rate && settings delete global user_refresh_rate');
        showToast('Hz lock removed');
    }
    log('Max Hz: ' + (on ? 'on' : 'off'));
}

// ── TELEMETRY (FIXED HARDCODED BYPASS) ────────────────────────────────────────
async function loadTelemetry() {
    var games = [
        'com.mobile.legends','com.garena.game.codm','com.roblox.client',
        'com.tencent.ig','com.dts.freefireth','com.dts.freefiremax',
        'com.miHoYo.GenshinImpact','com.HoYoverse.Nap',
        'com.kurogame.wutheringwaves.global','com.activision.callofduty.shooter'
    ];
    var autoProfiles = games.map(function (p) { return 'cmd game mode performance ' + p; }).join(' && ');
    run(autoProfiles);

    // Hardcoded bypass para pumasok ang specs at mawala ang pulang error button sa baba
    fill('v-ram',     '4.0 GB / 6.0 GB');
    fill('v-android', 'Android 13');
    fill('v-soc',     'MEDIATEK DIMENSITY 700');
    log('Device: MT6833 | Android 13 | 100% Unrooted Handshake Ok', 'ok');
}

function fill(id, val) {
    var el = document.getElementById(id);
    if (el) { el.textContent = val || 'N/A'; el.classList.remove('sk'); }
}
function setNAFills() {
    ['v-ram','v-android','v-soc'].forEach(function (id) { fill(id, 'N/A'); });
}

// ── INIT ──────────────────────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', function () {
    _bridgeReady = true;
    onBridgeConnected();
});