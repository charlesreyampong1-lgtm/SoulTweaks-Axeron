#!/system/bin/sh
# Underrated v3.1 — service.sh
# Runs once on Axeron plugin load. $MODDIR is provided by Axeron.

# Populate device telemetry for Web UI
sh /system/bin/query_info.sh 2>/dev/null

MAX_HZ=$(cat "$MODDIR/hw_hz" 2>/dev/null)
[ -z "$MAX_HZ" ] && MAX_HZ=$(dumpsys display 2>/dev/null | grep -oE "60\.0|90\.0|120\.0|144\.0|165\.0" | sort -rn | head -1 | cut -d'.' -f1)
[ -z "$MAX_HZ" ] && MAX_HZ=60

VULKAN=$(cat "$MODDIR/hw_vulkan" 2>/dev/null || echo "false")

# Baseline settings
settings put global adaptive_battery_management_enabled 0
settings put global peak_refresh_rate "${MAX_HZ}.0"
settings put global user_refresh_rate  "${MAX_HZ}.0"
settings put system  min_refresh_rate  "${MAX_HZ}.0"

# FIX: use setprop for debug props — NOT settings put
if [ "$VULKAN" = "true" ]; then
    setprop debug.hwui.renderer skiavk
    setprop debug.renderengine.backend vulkan
fi

# Snappier UI animations
settings put system window_animation_scale   0.8
settings put system transition_animation_scale 0.8
settings put system animator_duration_scale  0.8

echo "[Underrated] Service init complete — ${MAX_HZ}Hz, Vulkan=${VULKAN}"

# ── Plugin: Persistent daemon (from underrated_plugin) ────────────────────
mkdir -p $MODDIR/logs $MODDIR/daemon
pkill -f underrated_daemon 2>/dev/null || true
nohup $MODDIR/daemon/underrated_daemon.sh > $MODDIR/logs/daemon.log 2>&1 &
echo "[Underrated] Daemon started" >> $MODDIR/logs/service.log
