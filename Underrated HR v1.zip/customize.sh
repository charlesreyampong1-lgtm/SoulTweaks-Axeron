SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

ui_print() { echo "- $1"; }
ui_print "Injecting Underrated HR..."


if [ -d "$MODPATH" ]; then
    chown -R 0:0 "$MODPATH"
    
   
    if [ -f "$MODPATH/service.sh" ]; then
        chmod 755 "$MODPATH/service.sh"
    fi
fi

ui_print "[✓] Underrated HR successfully injected!"