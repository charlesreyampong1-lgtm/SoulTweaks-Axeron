#!/system/bin/sh

settings put system sensor_sampling_rate 500

echo "[✓] Underrated HR: 500Hz Sampling Applied"