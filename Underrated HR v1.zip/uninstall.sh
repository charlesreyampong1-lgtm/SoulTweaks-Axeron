#!/system/bin/sh
# Underrated HR: Revert to stock
settings put system sensor_sampling_rate 60