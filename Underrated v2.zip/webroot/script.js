// 2. ISOLATED GAME LAUNCH: Dagdag optimization laban sa frame drops kapag maraming effects
async function applyGameDownscale() {
    const scaleValue = parseFloat(document.getElementById('resSlider').value);
    const selectedGame = document.getElementById('gameSelector').value;
    const statusText = document.getElementById('status');

    let targetDensity = Math.round(440 * scaleValue);
    
    // Core Engine Tweaks (SkiaVK + Buffers)
    let engineInject = "settings put global debug.hwui.renderer skiavk && setprop debug.renderengine.backend skiavk && setprop debug.egl.buffcount 4 && setprop debug.gr.numframes 4";
    
    // ANTI-EFFECTS LAG TWEAKS: Pinupwersa ang hardware acceleration at nililimitahan ang rendering thread delay
    let performanceTweaks = "setprop debug.sf.showupdates 0 && setprop debug.sf.showcpu 0 && setprop debug.sf.showbackground 0 && setprop debug.sf.showfps 0 && setprop fontconfig.speed.optimize true && setprop ro.config.fha_enable true";
    
    // SURFACEFLINGER PIPELINE: Pinapabilis ang pag-clear ng memory stack para sa mga patay na entities (bots/effects)
    let graphicsTweaks = "setprop debug.composition.type gpu && setprop persist.sys.composition.type gpu && setprop dev.pm.gpu_mode 1 && setprop debug.enable.sglscale 1";

    let launchSequence = `wm density ${targetDensity} && monkey -p ${selectedGame} -c android.intent.category.LAUNCHER 1`;
    
    // Pagsasamahin lahat ng commands para isang bagsakan pag-click ng button
    let command = `${engineInject} && ${performanceTweaks} && ${graphicsTweaks} && ${launchSequence}`;
    
    if (typeof axeron !== 'undefined' && command !== "") {
        axeron.execute(command);
        statusText.innerText = `Underrated v2: Ultra Graphics Framework Applied!`;
        statusText.style.display = "block";
        setTimeout(() => { statusText.style.display = "none"; }, 3000);
    }
}