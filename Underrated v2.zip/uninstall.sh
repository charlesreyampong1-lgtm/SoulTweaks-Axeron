#!/system/bin/sh
# Underrated v2 - Official Uninstallation Clean Script

GAMES=(
    "com.roblox.client"
    "com.garena.game.codm"
    "com.mobile.legends"
    "com.dts.freefireth"
    "com.miHoYo.GenshinImpact"
    "com.activision.callofduty.shooter"
)

echo "[Underrated v2] Initiating deep purge configuration..."

# 1. Strip all downscaling factors and restore core gamemode parameters
for pkg in "${GAMES[@]}"; do
    device_config delete game_overlay "$pkg" >/dev/null 2>&1
    cmd game mode standard "$pkg" >/dev/null 2>&1
done

# 2. Reset graphics engines back to stock fallback layers
setprop debug.composition.type c2d
setprop debug.renderengine.backend default
settings put global debug.hwui.renderer default
setprop debug.egl.buffcount ""
setprop debug.gr.numframes ""

# 3. Release hardware panel frequency caps
settings delete global peak_refresh_rate >/dev/null 2>&1
settings delete system min_refresh_rate >/dev/null 2>&1

# 4. Normalize UI rendering properties
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0

# 5. Clean up battery power subsystem profiles
cmd battery reset >/dev/null 2>&1

echo "[Underrated v2] Purge complete. All stock structural rules successfully restored."