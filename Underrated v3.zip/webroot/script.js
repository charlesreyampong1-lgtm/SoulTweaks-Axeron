// ================= AUTOMATIC / PRE-LOAD SEQUENCE =================
window.addEventListener('DOMContentLoaded', () => {
    const games = [
        "com.roblox.client",
        "com.garena.game.codm",
        "com.mobile.legends",
        "com.dts.freefireth",
        "com.tencent.ig" 
    ];

    let autoGameProfiles = games.map(pkg => `cmd game mode performance ${pkg}`).join(" && ");
    let autoHardwareTweaks = "settings put global peak_refresh_rate 90.0 && settings put global user_refresh_rate 90.0 && settings put system min_refresh_rate 90.0 && settings put global adaptive_battery_management_enabled 0";
    
    if (typeof axeron !== 'undefined') {
        axeron.execute(`${autoGameProfiles} && ${autoHardwareTweaks}`);
        console.log("Underrated v3: Display refresh rate profiles pre-loaded.");
    }
});

function updateSliderLabel(val) {
    document.getElementById('sliderLabel').innerText = Math.round(val * 100) + "% Res";
}

// ================= ROUTER / NAVIGATION ENGINE =================
function switchUnderratedView(viewId) {
    document.querySelectorAll('.view-panel').forEach(v => v.style.display = 'none');
    document.getElementById('page-main').style.display = 'none';
    
    const target = document.getElementById(viewId);
    if (target) {
        target.style.display = 'block';
    } else if (viewId === 'page-main') {
        document.getElementById('page-main').style.display = 'block';
    }
}

function notifyUnderratedStatus(elementId, message, duration = 3000) {
    const box = document.getElementById(elementId);
    if (box) {
        box.innerText = message;
        box.style.display = "block";
        setTimeout(() => { box.style.display = "none"; }, duration);
    }
}

// ================= DYNAMIC AI CONTROLS (NON-ROOT) =================
let underratedAiInterval = null;
let isUnderratedAiActive = false;

function toggleUnderratedAiEngine() {
    const btn = document.getElementById('btn-underrated-ai');
    const games = ["com.garena.game.codm", "com.roblox.client"];
    
    if (!isUnderratedAiActive) {
        isUnderratedAiActive = true;
        btn.innerText = "Deactivate AI Mode";
        btn.style.background = "#ff3333";
        btn.style.color = "#fff";
        
        notifyUnderratedStatus('underrated-ai-status', "Underrated v3: AI Engine ACTIVE. Background tweaks running...");
        
        underratedAiInterval = setInterval(() => {
            if (typeof axeron !== 'undefined') {
                let targetGameCommands = games.map(pkg => `cmd game mode performance ${pkg}`).join(" && ");
                let refreshRateCommand = "settings put global peak_refresh_rate 90.0 && settings put global user_refresh_rate 90.0 && settings put system min_refresh_rate 90.0";
                let powerCommand = "settings put global power_id 2 && settings put global adaptive_battery_management_enabled 0";
                
                axeron.execute(`${targetGameCommands} && ${refreshRateCommand} && ${powerCommand}`);
                console.log("Underrated v3 (by SoulTweaks): AI Optimization applied.");
            }
        }, 5000);

    } else {
        isUnderratedAiActive = false;
        btn.innerText = "Activate AI Mode";
        btn.style.background = "#00cc66";
        btn.style.color = "#000";
        
        if (underratedAiInterval) {
            clearInterval(underratedAiInterval);
            underratedAiInterval = null;
        }
        
        if (typeof axeron !== 'undefined') {
            let resetCommand = "settings delete global peak_refresh_rate && settings delete global user_refresh_rate && settings delete system min_refresh_rate && settings put global power_id 1 && wm density reset";
            axeron.execute(resetCommand);
        }
        
        notifyUnderratedStatus('underrated-ai-status', "Underrated v3: AI Engine STOPPED. Parameters restored to default.", 4000);
    }
}

// ================= GAME TURBO CONTROLS (NON-ROOT) =================
function applyUnderratedGraphicsTurbo() {
    const statusText = document.getElementById('status');
    const targetId = statusText ? 'status' : 'underrated-ai-status';

    if (typeof axeron !== 'undefined') {
        let inject = "settings put global debug.hwui.renderer skiavk";
        let performanceTweaks = "settings put global peak_refresh_rate 90.0 && settings put global user_refresh_rate 90.0 && settings put system min_refresh_rate 90.0";
        
        axeron.execute(`${inject} && ${performanceTweaks}`);
        notifyUnderratedStatus(targetId, "Underrated v3: Non-Root Game Turbo Injected!");
    } else {
        notifyUnderratedStatus(targetId, "Error: Axeron environment not detected.");
    }
}

// ================= CORE UTILITY COMMANDS (NON-ROOT) =================
async function applyGameDownscale() {
    const scaleValue = parseFloat(document.getElementById('resSlider').value);
    const selectedGame = document.getElementById('gameSelector').value;
    const statusText = document.getElementById('status');
    const targetId = statusText ? 'status' : 'underrated-ai-status';

    let targetDensity = Math.round(440 * scaleValue);
    
    let engineInject = "settings put global debug.hwui.renderer skiavk && settings put global peak_refresh_rate 90.0 && settings put global user_refresh_rate 90.0";
    let launchSequence = `am force-stop ${selectedGame} && wm density ${targetDensity} && monkey -p ${selectedGame} -c android.intent.category.LAUNCHER 1`;
    
    let command = `${engineInject} && ${launchSequence}`;
    
    if (typeof axeron !== 'undefined' && command !== "") {
        axeron.execute(command);
        notifyUnderratedStatus(targetId, "Underrated v3: Engine Injected & Launching Game...");
    }
}

async function runCommand(action) {
    let command = "";
    let message = "";
    const statusText = document.getElementById('status');
    const targetId = statusText ? 'status' : 'underrated-ai-status';
    const games = [
        "com.roblox.client",
        "com.garena.game.codm",
        "com.mobile.legends",
        "com.dts.freefireth",
        "com.tencent.ig"
    ];

    switch(action) {
        case 'downscale_off': 
            command = "wm density reset && settings delete global debug.hwui.renderer";
            message = "Display resolution & graphics engine restored to default";
            break;
        case 'anim_fast': 
            command = "settings put global window_animation_scale 0.5 && settings put global transition_animation_scale 0.5 && settings put global animator_duration_scale 0.5 && settings put system window_animation_scale 0.5 && settings put system transition_animation_scale 0.5 && settings put system animator_duration_scale 0.5";
            message = "Animations optimized to 0.5x speed";
            break;
        case 'anim_normal': 
            command = "settings put global window_animation_scale 1.0 && settings put global transition_animation_scale 1.0 && settings put global animator_duration_scale 1.0 && settings put system window_animation_scale 1.0 && settings put system transition_animation_scale 1.0 && system set system animator_duration_scale 1.0";
            message = "Animations restored to normal configurations";
            break;
        case 'battery_unplug': 
            command = "cmd battery unplug";
            message = "Battery bypass mode injected successfully";
            break;
        case 'battery_reset': 
            command = "cmd battery reset";
            message = "Battery line profiles re-calibrated";
            break;
        case 'fps_reset': 
            let resetFps = games.map(pkg => `cmd game mode standard ${pkg}`).join(" && ");
            let resetHz = "wm density reset && settings delete global debug.hwui.renderer && settings delete global peak_refresh_rate && settings delete global user_refresh_rate && settings delete system min_refresh_rate && settings delete global adaptive_battery_management_enabled && settings delete global power_id";
            command = `${resetFps} && ${resetHz}`;
            message = "All engine telemetry & buffers successfully wiped to standard";
            break;
    }
    
    if (typeof axeron !== 'undefined' && command !== "") {
        axeron.execute(command);
        notifyUnderratedStatus(targetId, message);
    }
}