#!/system/bin/sh
# Underrated v3 - Official Uninstallation Clean Script
# Powered by: SoulTweaks (Non-Root Compliant)

GAMES=(
    "com.roblox.client"
    "com.garena.game.codm"
    "com.mobile.legends"
    "com.dts.freefireth"
    "com.tencent.ig"
    "com.vng.pubgmobile"
    "com.dts.freefiremax"
    "com.miHoYo.GenshinImpact"
    "com.activision.callofduty.shooter"
    "com.activision.callofduty.warzone"
    "com.HoYoverse.Nap"
    "com.kurogame.wutheringwaves.global"
)

echo "[Underrated v3] Initiating non-root purge configuration..."

# 1. Kill background runtime engine process loop
MODDIR="/sdcard/Android/data/frb.axeron.manager/files"
LOOP_FILE="$MODDIR/loop.sh"
LOG_FILE="$MODDIR/optimizer.log"

pkill -f "loop.sh" > /dev/null 2>&1
rm -f "$LOOP_FILE" "$LOG_FILE"

# 2. Strip all downscaling factors and restore core gamemode parameters
wm density reset >/dev/null 2>&1
for pkg in "${GAMES[@]}"; do
    device_config delete game_overlay "$pkg" >/dev/null 2>&1
    cmd game mode standard "$pkg" >/dev/null 2>&1
done

# 3. Clean up Global/System settings modifications (Ligtas at gumagana sa Non-Root)
settings delete global debug.hwui.renderer >/dev/null 2>&1
settings delete global peak_refresh_rate >/dev/null 2>&1
settings delete global user_refresh_rate >/dev/null 2>&1
settings delete system min_refresh_rate >/dev/null 2>&1
settings delete global adaptive_battery_management_enabled >/dev/null 2>&1
settings delete global power_id >/dev/null 2>&1

# 4. Normalize UI rendering animation scales to stock (1.0)
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0
settings put system window_animation_scale 1.0
settings put system transition_animation_scale 1.0
settings put system animator_duration_scale 1.0

# 5. Clean up battery power subsystem profiles
cmd battery reset >/dev/null 2>&1

echo "[Underrated v3] Purge complete. All safe structural rules successfully restored."