async function runCommand(action) {
    let command = "";
    let message = "";
    const statusText = document.getElementById('status');
    const games = [
        "com.roblox.client",
        "com.garena.game.codm",
        "com.mobile.legends",
        "com.dts.freefireth",
        "com.miHoYo.GenshinImpact",
        "com.activision.callofduty.shooter"
    ];

    switch(action) {
        case 'downscale_on': 
            command = games.map(pkg => "cmd game scaling mode 0.5 " + pkg).join(" && ");
            message = "Downscaling successfully injected";
            break;
        case 'downscale_off': 
            command = games.map(pkg => "cmd game scaling mode 1.0 " + pkg).join(" && ");
            message = "Resolution reset to default";
            break;
        case 'anim_fast': 
            command = "settings put global window_animation_scale 0.5 && settings put global transition_animation_scale 0.5 && settings put global animator_duration_scale 0.5";
            message = "Animations set to fast";
            break;
        case 'anim_normal': 
            command = "settings put global window_animation_scale 1.0 && settings put global transition_animation_scale 1.0 && settings put global animator_duration_scale 1.0";
            message = "Animations set to normal";
            break;
        case 'battery_unplug': 
            command = "cmd battery unplug";
            message = "Battery bypass enabled";
            break;
        case 'battery_reset': 
            command = "cmd battery reset";
            message = "Battery reset success";
            break;
        case 'fps_90': 
            command = "settings put global peak_refresh_rate 90.0 && settings put system min_refresh_rate 90.0";
            message = "90FPS mode enabled";
            break;
        case 'fps_reset': 
            command = "settings delete global peak_refresh_rate && settings delete system min_refresh_rate";
            message = "FPS settings reset";
            break;
    }
    
    if (typeof axeron !== 'undefined' && command !== "") {
        axeron.execute(command);
        statusText.innerText = message;
        statusText.style.display = "block";
        setTimeout(() => { statusText.style.display = "none"; }, 2000);
    }
}